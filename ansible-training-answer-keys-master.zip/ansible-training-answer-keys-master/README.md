# Answer Key for Ansible Training
This is the answer key for my Ansible training on Udemy at - https://www.udemy.com/learn-ansible/

Mumshad Mannambeth
